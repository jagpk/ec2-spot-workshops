"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 
Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
from airflow import DAG

from airflow.providers.amazon.aws.operators.emr import EmrAddStepsOperator
from airflow.providers.amazon.aws.sensors.emr import EmrStepSensor


from airflow.utils.dates import days_ago
from datetime import timedelta
import os
 
DAG_ID = os.path.basename(__file__).replace(".py", "")
 
DEFAULT_ARGS = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
}

EMR_CLUSTER_ID = 'j-xxxxx'

SPARK_STEPS_1 = [
    {
        'Name': 'calculate_pi',
        'ActionOnFailure': 'CONTINUE',
        'HadoopJarStep': {
            'Jar': 'command-runner.jar',
            'Args': ['/usr/lib/spark/bin/run-example', 'SparkPi', '10'],
        },
    }
]
SPARK_STEPS_2 = [
    {
        'Name': 'calculate_pi',
        'ActionOnFailure': 'CONTINUE',
        'HadoopJarStep': {
            'Jar': 'command-runner.jar',
            'Args': ['/usr/lib/spark/bin/run-example', 'SparkPi', '20'],
        },
    }
]

with DAG(
    dag_id=DAG_ID,
    default_args=DEFAULT_ARGS,
    dagrun_timeout=timedelta(hours=2),
    start_date=days_ago(1),
    schedule_interval='@once',
    tags=['emr'],
) as dag:
 
 
    step_adder_1 = EmrAddStepsOperator(
        task_id='add_steps_1',
        job_flow_id=EMR_CLUSTER_ID,
        aws_conn_id='aws_default',
        steps=SPARK_STEPS_1,
    )
 
    step_checker_1 = EmrStepSensor(
        task_id='watch_step_1',
        job_flow_id=EMR_CLUSTER_ID,
        step_id="{{ task_instance.xcom_pull(task_ids='add_steps_1', key='return_value')[0] }}",
        aws_conn_id='aws_default',
    )

    step_adder_2 = EmrAddStepsOperator(
        task_id='add_steps_2',
        job_flow_id=EMR_CLUSTER_ID,
        aws_conn_id='aws_default',
        steps=SPARK_STEPS_2,
    )

    step_checker_2 = EmrStepSensor(
        task_id='watch_step_2',
        job_flow_id=EMR_CLUSTER_ID,
        step_id="{{ task_instance.xcom_pull(task_ids='add_steps_2', key='return_value')[0] }}",
        aws_conn_id='aws_default',
    )

    step_adder_1 >> step_checker_1 >> step_adder_2 >> step_checker_2