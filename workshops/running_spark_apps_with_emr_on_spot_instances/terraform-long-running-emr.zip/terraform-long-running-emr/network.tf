#####################################################################################
# Terraform examples are meant to show an _example_ on how to use a resource or module
# per use-case. The code below should not be copied directly but referenced in order
# to build your own terraform code.
#####################################################################################

################################################################################
# VPC Module
################################################################################

module "emr-vpc" {
  source = "terraform-aws-modules/vpc/aws"

  name = "emr-vpc"
  cidr = local.emr-cidr

  azs                       = local.azs
  public_subnets            = [for k, v in local.azs : cidrsubnet(local.emr-cidr, 8, k)]
  private_subnets           = [for k, v in local.azs : cidrsubnet(local.emr-cidr, 8, k + 10)]
  map_public_ip_on_launch   = true
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = local.tags
}

################################################################################
# VPC Module
################################################################################

module "mwaa-vpc" {
  source = "terraform-aws-modules/vpc/aws"

  name = "mwaa-vpc"
  cidr = local.mwaa-cidr
  
  azs                = local.azs
  public_subnets      = [for k, v in local.azs : cidrsubnet(local.mwaa-cidr, 8, k)]
  private_subnets     = [for k, v in local.azs : cidrsubnet(local.mwaa-cidr, 8, k + 10)]

  enable_dns_hostnames = true
  enable_dns_support   = true
  enable_nat_gateway   = true
  single_nat_gateway   = true
  
  tags = local.tags
}

################################################################################
# VPC Peering
################################################################################

resource "aws_vpc_peering_connection" "emr-mwaa" {
  peer_vpc_id   = module.mwaa-vpc.vpc_id
  vpc_id        = module.emr-vpc.vpc_id
  auto_accept   = true

  tags = local.tags
  
  depends_on = [
    module.emr-vpc, module.mwaa-vpc
  ]
}

data "aws_route_tables" "emr-rts" {
  vpc_id = module.emr-vpc.vpc_id
  
  filter {
    name   = "tag:Name"
    values = ["emr-vpc-private*"]
  }
  
  depends_on = [
    module.emr-vpc, module.mwaa-vpc
  ]
}

data "aws_route_tables" "mwaa-rts" {
  vpc_id = module.mwaa-vpc.vpc_id

  filter {
    name   = "tag:Name"
    values = ["mwaa-vpc-private"]
  }
  
  depends_on = [
    module.emr-vpc, module.mwaa-vpc
  ]
}

resource "aws_route" "emr-rt" {
  count                     = var.numberofazs
  route_table_id            = data.aws_route_tables.emr-rts.ids[count.index]
  destination_cidr_block    = module.mwaa-vpc.vpc_cidr_block
  vpc_peering_connection_id = aws_vpc_peering_connection.emr-mwaa.id
  
  depends_on = [
    aws_vpc_peering_connection.emr-mwaa
  ]
  
}

resource "aws_route" "mwaa-rt" {
  route_table_id            = data.aws_route_tables.mwaa-rts.ids[0]
  destination_cidr_block    = module.emr-vpc.vpc_cidr_block
  vpc_peering_connection_id = aws_vpc_peering_connection.emr-mwaa.id
  
  depends_on = [
    aws_vpc_peering_connection.emr-mwaa
  ]
  
}


################################################################################
# Security Groups
################################################################################
# ---------------------------------------------------------------------------------------------------------------------
# MWAA Security Group
# ---------------------------------------------------------------------------------------------------------------------
resource "aws_security_group" "mwaa" {
  name_prefix = "mwaa-"
  description = "Security group for MWAA environment"
  vpc_id      = module.mwaa-vpc.vpc_id

  lifecycle {
    create_before_destroy = true
  }

  tags = local.tags
}

resource "aws_security_group_rule" "mwaa_sg_inbound" {
  type                     = "ingress"
  from_port                = 0
  to_port                  = 0
  protocol                 = "all"
  source_security_group_id = aws_security_group.mwaa.id
  security_group_id        = aws_security_group.mwaa.id
  description              = "Amazon MWAA inbound access"
}


#tfsec:ignore:aws-vpc-no-public-egress-sgr
resource "aws_security_group_rule" "mwaa_sg_outbound" {
  type              = "egress"
  from_port         = 0
  to_port           = 0
  protocol          = "all"
  cidr_blocks       = ["0.0.0.0/0"]
  security_group_id = aws_security_group.mwaa.id
  description       = "Amazon MWAA outbound access"
}