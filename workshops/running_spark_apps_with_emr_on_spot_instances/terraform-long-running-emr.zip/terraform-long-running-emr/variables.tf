variable "numberofazs" {
  description = "Number of azs"
  type        = string
  default     = "2"
}

