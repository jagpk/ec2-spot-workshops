#####################################################################################
# Terraform examples are meant to show an _example_ on how to use a resource or module
# per use-case. The code below should not be copied directly but referenced in order
# to build your own terraform code.
#####################################################################################

#-----------------------------------------------------------
# Create an S3 bucket and upload sample DAG
#-----------------------------------------------------------
module "s3-mwaa-bucket" {
  source  = "terraform-aws-modules/s3-bucket/aws"

  bucket_prefix = "mwaa-"

  # Allow deletion of non-empty bucket
  # Example usage only - not recommended for production
  force_destroy = true

  attach_deny_insecure_transport_policy = true
  attach_require_latest_tls_policy      = true

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm = "AES256"
      }
    }
  }

  tags = local.tags
}

# Upload DAGS
resource "aws_s3_object" "object1" {
  for_each = fileset("dags/", "*")
  bucket   = module.s3-mwaa-bucket.s3_bucket_id
  key      = "dags/${each.value}"
  source   = "dags/${each.value}"
  etag     = filemd5("dags/${each.value}")
}

# Upload plugins/requirements.txt
resource "aws_s3_object" "reqs" {
  for_each = fileset("mwaa/", "*")
  bucket   = module.s3-mwaa-bucket.s3_bucket_id
  key      = each.value
  source   = "mwaa/${each.value}"
  etag     = filemd5("mwaa/${each.value}")
}

#-----------------------------------------------------------
# NOTE: MWAA Airflow environment takes minimum of 20 mins
#-----------------------------------------------------------
resource "aws_mwaa_environment" "mwaa" {
  dag_s3_path        = "dags/"
  execution_role_arn = aws_iam_role.mwaa.arn

  logging_configuration {
    dag_processing_logs {
      enabled   = true
      log_level = "DEBUG"
    }

    scheduler_logs {
      enabled   = true
      log_level = "INFO"
    }

    task_logs {
      enabled   = true
      log_level = "INFO"
    }

    webserver_logs {
      enabled   = true
      log_level = "ERROR"
    }

    worker_logs {
      enabled   = true
      log_level = "CRITICAL"
    }
  }

  name               = local.mwaa-name
  
  airflow_configuration_options = {
    "core.load_default_connections" = "false"
    "core.load_examples"            = "false"
    "webserver.dag_default_view"    = "tree"
    "webserver.dag_orientation"     = "TB"
  }
  
  network_configuration {
    security_group_ids = [aws_security_group.mwaa.id]
    subnet_ids         = module.mwaa-vpc.private_subnets
  }

  webserver_access_mode = "PUBLIC_ONLY" # Default PRIVATE_ONLY for production environments
  source_bucket_arn = module.s3-mwaa-bucket.s3_bucket_arn
}

