#####################################################################################
# Terraform examples are meant to show an _example_ on how to use a resource or module
# per use-case. The code below should not be copied directly but referenced in order
# to build your own terraform code.
#####################################################################################

terraform {
  backend "s3" {
    # Replace this with your bucket name!
    bucket         = "<terraform-backend-bucket>"
    key            = "emr-long-running/terraform.tfstate"
    region         = "<region>"
  }
}