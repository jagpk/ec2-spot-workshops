#####################################################################################
# Terraform examples are meant to show an _example_ on how to use a resource or module
# per use-case. The code below should not be copied directly but referenced in order
# to build your own terraform code.
#####################################################################################

#10.0.0.0 — 10.255.255.255;
#172.16.0.0 — 172.31.255.255; 
#192.168.0.0 — 192.168.255.255

locals {
  mwaa-name   = "emr-workshop"
  emr-name   = "emr-long-running-cluster"
  region      = data.aws_region.current.name
  azs          = slice(data.aws_availability_zones.available.names, 0, var.numberofazs)
  mwaa-bucket-name  = format("%s-%s", "aws-ia-mwaa", data.aws_caller_identity.current.account_id)
  emr-cidr     = "10.1.0.0/16"
  mwaa-cidr    = "172.16.0.0/16"
  tags      = {
    environment     = "emr-workshop"
    workload        = "emr-6.x"
    
  }
}